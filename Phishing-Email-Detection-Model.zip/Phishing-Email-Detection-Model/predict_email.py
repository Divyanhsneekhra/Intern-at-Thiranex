from __future__ import annotations

import argparse
from pathlib import Path

import joblib

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model" / "phishing_model.joblib"


def main():
    parser = argparse.ArgumentParser(
        description="Classify an email as Phishing or Safe."
    )
    parser.add_argument(
        "email",
        nargs="?",
        help="Email text. If omitted, the program asks for input.",
    )
    args = parser.parse_args()

    if not MODEL_PATH.exists():
        raise SystemExit("Model not found. Run: python train_model.py")

    email_text = args.email or input("Paste the email text: ").strip()
    if not email_text:
        raise SystemExit("Email text cannot be empty.")

    model = joblib.load(MODEL_PATH)
    prediction = model.predict([email_text])[0]
    probabilities = model.predict_proba([email_text])[0]
    classes = list(model.classes_)
    confidence = probabilities[classes.index(prediction)]

    print("\nPrediction:", prediction)
    print(f"Confidence: {confidence:.2%}")

    if prediction == "Phishing":
        print("Advice: Do not click links or share passwords, OTPs, or banking details.")
    else:
        print("Advice: The message appears safe, but still verify unexpected requests.")


if __name__ == "__main__":
    main()
