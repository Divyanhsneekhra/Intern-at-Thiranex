from __future__ import annotations

import json
import re
from pathlib import Path

import joblib
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, ConfusionMatrixDisplay
from sklearn.model_selection import train_test_split
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.preprocessing import FunctionTransformer

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "dataset" / "emails.csv"
MODEL_PATH = BASE_DIR / "model" / "phishing_model.joblib"
OUTPUT_DIR = BASE_DIR / "outputs"

URL_PATTERN = re.compile(r"https?://\S+|www\.\S+", re.IGNORECASE)
SUSPICIOUS_WORDS = [
    "urgent", "verify", "password", "account", "suspended", "winner",
    "prize", "click", "immediately", "otp", "pin", "gift card",
    "banking information", "enable macros", "payment failed",
]


def lexical_features(texts):
    """Convert each email into a small set of numeric URL/keyword features."""
    features = []
    for text in texts:
        lowered = str(text).lower()
        urls = URL_PATTERN.findall(lowered)
        features.append([
            len(urls),
            sum(len(url) for url in urls),
            lowered.count("!"),
            sum(lowered.count(word) for word in SUSPICIOUS_WORDS),
            int("http://" in lowered),
            int("bit.ly" in lowered or "tinyurl" in lowered),
            len(lowered),
        ])
    return features


def build_pipeline():
    text_pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(
            lowercase=True,
            ngram_range=(1, 2),
            min_df=1,
            max_features=3000,
            strip_accents="unicode",
        ))
    ])

    numeric_pipeline = Pipeline([
        ("features", FunctionTransformer(lexical_features, validate=False))
    ])

    combined = FeatureUnion([
        ("text_features", text_pipeline),
        ("email_features", numeric_pipeline),
    ])

    return Pipeline([
        ("features", combined),
        ("classifier", LogisticRegression(max_iter=1000, random_state=42)),
    ])


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(DATA_PATH)
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"],
        df["label"],
        test_size=0.30,
        random_state=42,
        stratify=df["label"],
    )

    model = build_pipeline()
    model.fit(X_train, y_train)

    predictions = model.predict(X_test)
    accuracy = accuracy_score(y_test, predictions)
    report = classification_report(y_test, predictions, output_dict=True)

    joblib.dump(model, MODEL_PATH)

    metrics = {
        "accuracy": round(float(accuracy), 4),
        "test_samples": int(len(y_test)),
        "classification_report": report,
    }
    (OUTPUT_DIR / "metrics.json").write_text(
        json.dumps(metrics, indent=2), encoding="utf-8"
    )

    display = ConfusionMatrixDisplay.from_predictions(
        y_test,
        predictions,
        display_labels=["Phishing", "Safe"],
        cmap="Blues",
        colorbar=False,
    )
    display.ax_.set_title("Phishing Email Detection Confusion Matrix")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "confusion_matrix.png", dpi=180)
    plt.close()

    lines = [
        "PHISHING EMAIL DETECTION MODEL",
        "=" * 42,
        f"Accuracy: {accuracy:.2%}",
        f"Training samples: {len(X_train)}",
        f"Testing samples: {len(X_test)}",
        "",
        classification_report(y_test, predictions),
    ]
    (OUTPUT_DIR / "evaluation_report.txt").write_text(
        "\n".join(lines), encoding="utf-8"
    )

    print(f"Model saved to: {MODEL_PATH}")
    print(f"Accuracy: {accuracy:.2%}")
    print(f"Confusion matrix: {OUTPUT_DIR / 'confusion_matrix.png'}")
    print(f"Evaluation report: {OUTPUT_DIR / 'evaluation_report.txt'}")


if __name__ == "__main__":
    main()
