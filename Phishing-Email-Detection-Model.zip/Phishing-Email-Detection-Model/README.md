# Phishing Email Detection Model

A machine-learning mini project built with **Python and Scikit-learn**.  
It classifies emails as **Phishing** or **Safe** using textual content and basic URL-related features.

## Key features

- Trains on a labeled dataset of phishing and legitimate email examples
- Uses TF-IDF word and phrase features
- Extracts URL counts, insecure HTTP usage, shortened-link signals and suspicious keywords
- Classifies new emails as `Phishing` or `Safe`
- Displays model accuracy
- Generates a confusion matrix and classification report
- Includes both command-line and Streamlit interfaces

## Project structure

```text
Phishing-Email-Detection-Model/
├── app.py
├── predict_email.py
├── train_model.py
├── requirements.txt
├── dataset/
│   └── emails.csv
├── model/
│   └── phishing_model.joblib
└── outputs/
    ├── confusion_matrix.png
    ├── evaluation_report.txt
    └── metrics.json
```

## Installation

Open a terminal inside the project folder and run:

```bash
pip install -r requirements.txt
```

## Train and evaluate the model

```bash
python train_model.py
```

This command:

1. Loads the dataset
2. Splits it into training and testing data
3. Trains a Logistic Regression model
4. Calculates accuracy
5. Saves the model
6. Creates the confusion matrix and evaluation report

## Test a new email in the terminal

```bash
python predict_email.py
```

You can also provide the email directly:

```bash
python predict_email.py "Urgent! Verify your account at http://fake.example"
```

## Run the graphical web application

```bash
streamlit run app.py
```

A local URL will appear in the terminal. Open it in your browser.

## Machine-learning workflow

1. **Dataset preparation:** Emails are labeled as `Phishing` or `Safe`.
2. **Text preprocessing:** TF-IDF converts email words and phrases into numerical features.
3. **Feature extraction:** The program checks URLs, suspicious keywords, exclamation marks and message length.
4. **Training:** Logistic Regression learns patterns from the training data.
5. **Evaluation:** Accuracy, classification report and confusion matrix are generated.
6. **Prediction:** The trained model classifies new email content.

## Submission description

> Developed a phishing email detection model using Python and Scikit-learn. The model uses TF-IDF textual features along with URL and suspicious-keyword indicators to classify emails as Phishing or Safe. It calculates accuracy, generates a classification report and confusion matrix, and provides both command-line and Streamlit interfaces for testing new emails.

## Suggested GitHub repository name

```text
phishing-email-detection-model
```

## Important note

The included dataset is a small, synthetic educational dataset. For real-world performance, train the model on a larger verified dataset. This tool should not be the sole basis for security decisions.
