from pathlib import Path

import joblib
import streamlit as st

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "model" / "phishing_model.joblib"

st.set_page_config(
    page_title="Phishing Email Detection",
    page_icon="🛡️",
    layout="centered",
)

st.title("🛡️ Phishing Email Detection Model")
st.write(
    "Paste an email below. The machine-learning model analyzes textual "
    "content, suspicious keywords and URL-related features."
)

if not MODEL_PATH.exists():
    st.error("Model file not found. Run `python train_model.py` first.")
    st.stop()

model = joblib.load(MODEL_PATH)

email_text = st.text_area(
    "Email content",
    height=220,
    placeholder="Example: Urgent! Verify your account using http://example.com",
)

if st.button("Analyze Email", type="primary"):
    if not email_text.strip():
        st.warning("Please enter some email text.")
    else:
        prediction = model.predict([email_text])[0]
        probabilities = model.predict_proba([email_text])[0]
        classes = list(model.classes_)
        confidence = probabilities[classes.index(prediction)]

        if prediction == "Phishing":
            st.error(f"Prediction: Phishing ({confidence:.2%} confidence)")
            st.warning(
                "Do not click unknown links or share passwords, OTPs, PINs, "
                "or banking information."
            )
        else:
            st.success(f"Prediction: Safe ({confidence:.2%} confidence)")
            st.info("Still verify unexpected links, attachments and requests.")

st.caption(
    "Educational model only. Do not use it as the sole basis for security decisions."
)
