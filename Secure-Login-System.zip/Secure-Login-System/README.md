# Secure Login System

A secure login web application built with Flask, SQLite and bcrypt.

## Features

- User registration and login
- Bcrypt password hashing with 12 rounds
- Strong password validation
- Parameterized SQLite queries to prevent SQL injection
- CSRF protection on forms
- Secure server-side authentication flow
- HTTP-only and SameSite session cookies
- Automatic session expiry
- Secure logout
- Login rate limiting
- Security response headers
- Optional TOTP two-factor authentication (2FA)
- Responsive interface

## Project structure

```text
Secure-Login-System/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── static/
│   └── style.css
└── templates/
    ├── base.html
    ├── index.html
    ├── register.html
    ├── login.html
    ├── dashboard.html
    ├── setup_2fa.html
    └── verify_2fa.html
```

The `users.db` database is created automatically when the application starts.

## Installation

Open a terminal inside the project folder.

### 1. Create a virtual environment

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

macOS/Linux:

```bash
python3 -m venv venv
source venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Set a secret key

Windows PowerShell:

```powershell
$env:SECRET_KEY="replace-with-a-long-random-secret"
```

macOS/Linux:

```bash
export SECRET_KEY="replace-with-a-long-random-secret"
```

Generate a random key with:

```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

### 4. Start the application

```bash
python app.py
```

Open the local address shown in the terminal, normally:

```text
http://127.0.0.1:5000
```

## Testing the main features

1. Register with a strong password.
2. Log in and open the protected dashboard.
3. Enable 2FA from the dashboard.
4. Scan the QR code using an authenticator app.
5. Log out and log in again with password plus 2FA code.
6. Try an incorrect password several times to demonstrate rate limiting.

## Security controls

### Password security

Passwords are never stored in plain text. Flask-Bcrypt creates salted bcrypt password hashes.

### SQL injection protection

All database operations use parameterized SQL statements:

```python
db.execute("SELECT * FROM users WHERE email = ?", (email,))
```

### CSRF protection

Flask-WTF automatically validates a secret CSRF token for every form submission.

### Session security

The application uses HTTP-only, SameSite cookies, a limited session lifetime and secure logout.

### Two-factor authentication

Optional TOTP-based 2FA works with authenticator applications such as Google Authenticator and Microsoft Authenticator.

## Production note

The built-in Flask server is for development only. A production deployment should use HTTPS, a production WSGI server, secure environment variables and persistent rate-limit storage.

## Suggested submission description

> Developed a secure login web application using Flask, SQLite and bcrypt. The system includes user registration, strong input validation, parameterized SQL queries, CSRF protection, secure session management, logout, login rate limiting, security headers and optional TOTP-based two-factor authentication.

## Suggested GitHub repository name

```text
secure-login-system
```
