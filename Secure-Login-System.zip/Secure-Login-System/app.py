from __future__ import annotations

import base64
import io
import os
import re
import sqlite3
import time
from functools import wraps
from pathlib import Path
from urllib.parse import urlparse, urljoin

import pyotp
import qrcode
from flask import (
    Flask, flash, g, redirect, render_template,
    request, session, url_for
)
from flask_bcrypt import Bcrypt
from flask_wtf import CSRFProtect
from wtforms import BooleanField, PasswordField, StringField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, Length, Regexp
from flask_wtf import FlaskForm

BASE_DIR = Path(__file__).resolve().parent
DATABASE = BASE_DIR / "users.db"

app = Flask(__name__)
app.config.update(
    SECRET_KEY=os.getenv("SECRET_KEY", "change-this-development-key"),
    WTF_CSRF_TIME_LIMIT=3600,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.getenv("FLASK_ENV") == "production",
    PERMANENT_SESSION_LIFETIME=1800,
)

bcrypt = Bcrypt(app)
csrf = CSRFProtect(app)

# Small in-memory rate-limit store for this educational project.
LOGIN_ATTEMPTS: dict[str, list[float]] = {}
MAX_ATTEMPTS = 5
WINDOW_SECONDS = 300


class RegisterForm(FlaskForm):
    name = StringField(
        "Full name",
        validators=[
            DataRequired(),
            Length(min=2, max=60),
            Regexp(r"^[A-Za-z][A-Za-z .'-]*$", message="Enter a valid name."),
        ],
    )
    email = StringField(
        "Email",
        validators=[DataRequired(), Email(), Length(max=120)],
    )
    password = PasswordField(
        "Password",
        validators=[
            DataRequired(),
            Length(min=10, max=128),
            Regexp(
                r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^A-Za-z0-9]).+$",
                message="Use uppercase, lowercase, number and special character.",
            ),
        ],
    )
    confirm_password = PasswordField(
        "Confirm password",
        validators=[DataRequired(), EqualTo("password")],
    )
    submit = SubmitField("Create Account")


class LoginForm(FlaskForm):
    email = StringField("Email", validators=[DataRequired(), Email(), Length(max=120)])
    password = PasswordField("Password", validators=[DataRequired(), Length(max=128)])
    remember = BooleanField("Remember me")
    submit = SubmitField("Login")


class TwoFactorForm(FlaskForm):
    code = StringField(
        "6-digit authentication code",
        validators=[
            DataRequired(),
            Regexp(r"^\d{6}$", message="Enter a valid 6-digit code."),
        ],
    )
    submit = SubmitField("Verify")


def get_db() -> sqlite3.Connection:
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db


@app.teardown_appcontext
def close_db(_error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db() -> None:
    db = sqlite3.connect(DATABASE)
    db.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            two_factor_secret TEXT,
            two_factor_enabled INTEGER NOT NULL DEFAULT 0,
            created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
        """
    )
    db.commit()
    db.close()


def login_required(view):
    @wraps(view)
    def wrapped_view(**kwargs):
        if "user_id" not in session:
            flash("Please log in to continue.", "warning")
            return redirect(url_for("login"))
        return view(**kwargs)
    return wrapped_view


def is_safe_redirect(target: str) -> bool:
    host_url = urlparse(request.host_url)
    redirect_url = urlparse(urljoin(request.host_url, target))
    return (
        redirect_url.scheme in ("http", "https")
        and host_url.netloc == redirect_url.netloc
    )


def client_key() -> str:
    return request.headers.get("X-Forwarded-For", request.remote_addr or "unknown").split(",")[0].strip()


def rate_limited() -> bool:
    key = client_key()
    now = time.time()
    attempts = [t for t in LOGIN_ATTEMPTS.get(key, []) if now - t < WINDOW_SECONDS]
    LOGIN_ATTEMPTS[key] = attempts
    return len(attempts) >= MAX_ATTEMPTS


def record_failed_login() -> None:
    key = client_key()
    LOGIN_ATTEMPTS.setdefault(key, []).append(time.time())


def clear_login_attempts() -> None:
    LOGIN_ATTEMPTS.pop(client_key(), None)


@app.after_request
def add_security_headers(response):
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; img-src 'self' data:; style-src 'self'; "
        "script-src 'self'; frame-ancestors 'none'; base-uri 'self';"
    )
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    return response


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    form = RegisterForm()
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        name = form.name.data.strip()
        password_hash = bcrypt.generate_password_hash(
            form.password.data, rounds=12
        ).decode("utf-8")

        try:
            db = get_db()
            db.execute(
                "INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)",
                (name, email, password_hash),
            )
            db.commit()
        except sqlite3.IntegrityError:
            flash("An account with this email already exists.", "danger")
            return render_template("register.html", form=form)

        flash("Registration successful. You can now log in.", "success")
        return redirect(url_for("login"))

    return render_template("register.html", form=form)


@app.route("/login", methods=["GET", "POST"])
def login():
    if "user_id" in session:
        return redirect(url_for("dashboard"))

    form = LoginForm()
    if form.validate_on_submit():
        if rate_limited():
            flash("Too many failed attempts. Try again in 5 minutes.", "danger")
            return render_template("login.html", form=form), 429

        email = form.email.data.strip().lower()
        user = get_db().execute(
            "SELECT * FROM users WHERE email = ?", (email,)
        ).fetchone()

        valid_password = user and bcrypt.check_password_hash(
            user["password_hash"], form.password.data
        )

        if not valid_password:
            record_failed_login()
            flash("Invalid email or password.", "danger")
            return render_template("login.html", form=form)

        clear_login_attempts()
        session.clear()
        session.permanent = bool(form.remember.data)

        if user["two_factor_enabled"]:
            session["pending_2fa_user_id"] = user["id"]
            return redirect(url_for("verify_2fa"))

        session["user_id"] = user["id"]
        session["user_name"] = user["name"]

        next_page = request.args.get("next")
        if next_page and is_safe_redirect(next_page):
            return redirect(next_page)
        return redirect(url_for("dashboard"))

    return render_template("login.html", form=form)


@app.route("/verify-2fa", methods=["GET", "POST"])
def verify_2fa():
    user_id = session.get("pending_2fa_user_id")
    if not user_id:
        return redirect(url_for("login"))

    user = get_db().execute(
        "SELECT * FROM users WHERE id = ?", (user_id,)
    ).fetchone()
    if not user:
        session.clear()
        return redirect(url_for("login"))

    form = TwoFactorForm()
    if form.validate_on_submit():
        totp = pyotp.TOTP(user["two_factor_secret"])
        if totp.verify(form.code.data, valid_window=1):
            session.clear()
            session["user_id"] = user["id"]
            session["user_name"] = user["name"]
            flash("Two-factor authentication successful.", "success")
            return redirect(url_for("dashboard"))

        flash("Invalid or expired authentication code.", "danger")

    return render_template("verify_2fa.html", form=form)


@app.route("/dashboard")
@login_required
def dashboard():
    user = get_db().execute(
        "SELECT id, name, email, two_factor_enabled, created_at "
        "FROM users WHERE id = ?",
        (session["user_id"],),
    ).fetchone()
    return render_template("dashboard.html", user=user)


@app.route("/setup-2fa", methods=["GET", "POST"])
@login_required
def setup_2fa():
    db = get_db()
    user = db.execute(
        "SELECT * FROM users WHERE id = ?", (session["user_id"],)
    ).fetchone()

    secret = user["two_factor_secret"] or pyotp.random_base32()
    if not user["two_factor_secret"]:
        db.execute(
            "UPDATE users SET two_factor_secret = ? WHERE id = ?",
            (secret, user["id"]),
        )
        db.commit()

    uri = pyotp.TOTP(secret).provisioning_uri(
        name=user["email"],
        issuer_name="Secure Login System",
    )

    image = qrcode.make(uri)
    buffer = io.BytesIO()
    image.save(buffer, format="PNG")
    qr_code = base64.b64encode(buffer.getvalue()).decode("ascii")

    form = TwoFactorForm()
    if form.validate_on_submit():
        if pyotp.TOTP(secret).verify(form.code.data, valid_window=1):
            db.execute(
                "UPDATE users SET two_factor_enabled = 1 WHERE id = ?",
                (user["id"],),
            )
            db.commit()
            flash("Two-factor authentication has been enabled.", "success")
            return redirect(url_for("dashboard"))
        flash("Invalid code. Please try again.", "danger")

    return render_template(
        "setup_2fa.html",
        form=form,
        qr_code=qr_code,
        secret=secret,
    )


@app.post("/disable-2fa")
@login_required
def disable_2fa():
    db = get_db()
    db.execute(
        "UPDATE users SET two_factor_enabled = 0, two_factor_secret = NULL "
        "WHERE id = ?",
        (session["user_id"],),
    )
    db.commit()
    flash("Two-factor authentication has been disabled.", "success")
    return redirect(url_for("dashboard"))


@app.post("/logout")
@login_required
def logout():
    session.clear()
    flash("You have been logged out securely.", "success")
    return redirect(url_for("login"))


if __name__ == "__main__":
    init_db()
    app.run(debug=os.getenv("FLASK_DEBUG") == "1")
